#include "edge.hpp"

//construtor
Edge::Edge(int a, int b, double w) {
	this->a = a;
	this->b = b;
	this->weight = w;
}

//getters:
//retorna um vértice da aresta
int Edge::getVertexA() {
	return this->a;
}

//retorna o outro vértice
int Edge::getVertexB() {
	return this->b;
}

//retorna o peso
double Edge::getWeight() {
	return this->weight;
}