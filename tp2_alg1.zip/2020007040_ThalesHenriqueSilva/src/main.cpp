#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include "edge.hpp"

using namespace std;

vector<int> parent, depth;

//----Funções da DSU----
//cria um conjunto
void create_set(int v) {
    parent[v] = v;
    depth[v] = 0;
}

//encontra o representante/raiz
//do conjunto do elemento v
int find_set(int v) {
    if (v == parent[v])
        return v;
    return (parent[v] = find_set(parent[v]));
}

//junta os conjuntos
void merge_sets(int a, int b) {
    a = find_set(a);
    b = find_set(b);
	//os conjuntos só são unidos
	//se forem diferentes
    if (a != b) {
		//insere no conjunto de maior profundidade
        if (depth[a] < depth[b]) {
			//troca a e b;
			int aux = b;
			b = a;
			a = aux;
		}        
        parent[b] = a;
		//aumenta a profundidade, se necessário
        if (depth[a] == depth[b])
            depth[a]++;
    }
}
//----

//distância euclidiana
double dist(int x1, int y1, int x2, int y2) {
    return sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
}

int main() {
	//entrada
    int N, K, D, M, C;
    cin >> N >> K >> D >> M >> C;
	
	//coordenadas
    vector<pair<int,int>> points;
    for (int i = 0;i < N;i++) {
        int x,y;
        cin >> x >> y;
        points.push_back(make_pair(x,y));
    }
    
	//criando arestas
	vector<Edge> edges;
    for (int i = 0;i < N;i++) {
        for (int j = i + 1;j < N;j++) {
            double d = dist(points[i].first,points[i].second,points[j].first,points[j].second);
            Edge aux(i, j, d);
            edges.push_back(aux);
        }
    }
    
	//Algoritmo de Kruskal
    vector<Edge> MST;
    parent.resize(N);
    depth.resize(N);
	//cria os N conjuntos
    for (int i = 0; i < N; i++) {
		create_set(i);
	}
        
	//ordenação das arestas
    sort(edges.begin(), edges.end());
    
	//percorre arestas ordenadas
    for (Edge e : edges) {
		//se a aresta não gera um ciclo, ela é inserida
        if (find_set(e.getVertexA()) != find_set(e.getVertexB())) {
            MST.push_back(e);
            merge_sets(e.getVertexA(), e.getVertexB());
		}
	}
    
	//Atribuições de tipos de transporte
    int num = MST.size() - (D - 1); //arestas com drones
    
	//calcula os custos
	double motorCycleCost = 0, truckCost = 0; 
    for (int i = num - 1;i >= 0;i--) {
        if (MST[i].getWeight() <= K) {
			//custo relacionado a moto
            motorCycleCost += (MST[i].getWeight()) * M;
        } else {
			//custo relacionado a caminhão
            truckCost += (MST[i].getWeight()) * C;
        }
    }
    
	//resultado
	cout << std::fixed << setprecision(3) << motorCycleCost << " " << truckCost;
}