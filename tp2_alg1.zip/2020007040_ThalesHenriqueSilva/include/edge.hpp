#ifndef EDGE_HPP
#define EDGE_HPP

using namespace std;

class Edge {
private:
	//atributos
	int a, b; //vértices
	double weight; //peso
	
public:
	//construtor
	Edge(int a, int b, double w);
	//getters
	int getVertexA();
	int getVertexB();
	double getWeight();
	bool operator < (Edge const & other) {
		return weight < other.weight;
	}
};

#endif